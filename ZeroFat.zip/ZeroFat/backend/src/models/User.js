const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, index: true, unique: true, sparse: true },
  phone: { type: String, index: true, unique: true, sparse: true },
  passwordHash: { type: String },
  role: { type: String, enum: ['owner','admin','nutritionist','client'], required: true },
  avatarUrl: String,
  createdAt: { type: Date, default: Date.now },
  meta: {}
});
module.exports = mongoose.model('User', UserSchema);
