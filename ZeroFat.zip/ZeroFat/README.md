# ZeroFat - Local setup (backend + flutter app + admin)

## Prereqs
- Node 18+, npm
- MongoDB running locally
- Flutter SDK
- (Optional) AWS S3 or local filesystem for uploads
- Stripe account for payment testing (test keys)

## Backend
1. cd backend
2. cp .env.example .env and fill values (JWT secrets, MONGO_URI, GEMINI_KEY -> placeholder)
3. npm install
4. npm run dev

## Flutter
1. cd flutter_app
2. flutter pub get
3. flutter run

## Admin
1. cd admin_dashboard
2. npm install
3. npm run start
