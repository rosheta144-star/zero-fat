import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function Users(){ return <div>Users admin</div> }
function Clients(){ return <div>Clients admin</div> }

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Users/>}/>
        <Route path="/clients" element={<Clients/>}/>
      </Routes>
    </BrowserRouter>
  );
}
