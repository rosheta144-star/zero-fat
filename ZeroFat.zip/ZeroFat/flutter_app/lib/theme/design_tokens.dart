import 'package:flutter/material.dart';

class ZF {
  static const primary = Color(0xFF6C63FF);
  static const accent = Color(0xFF00C853);
  static const text = Color(0xFF222222);
  static const background = Color(0xFFFFFFFF);

  static const double spacingXS = 4;
  static const double spacingS = 8;
  static const double spacingM = 16;
  static const double spacingL = 24;

  static const BorderRadius radiusSm = BorderRadius.all(Radius.circular(8));
  static const BorderRadius radiusMd = BorderRadius.all(Radius.circular(16));

  static const double h1 = 28;
  static const double h2 = 22;
  static const double body = 16;
  static const double caption = 12;
}

ThemeData appTheme(Locale locale) {
  final isArabic = locale.languageCode == 'ar';
  return ThemeData(
    primaryColor: ZF.primary,
    scaffoldBackgroundColor: ZF.background,
    fontFamily: isArabic ? 'Tajawal' : 'Roboto',
    textTheme: TextTheme(
      headline1: TextStyle(fontSize: ZF.h1, color: ZF.text),
      bodyText1: TextStyle(fontSize: ZF.body, color: ZF.text),
      caption: TextStyle(fontSize: ZF.caption, color: ZF.text),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: ZF.primary,
      centerTitle: true,
    ),
  );
}
