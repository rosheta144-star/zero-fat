import 'package:flutter/material.dart';
import '../theme/design_tokens.dart';

class OnboardingScreen extends StatefulWidget {
  final Function(Locale) onLocaleChange;
  OnboardingScreen({required this.onLocaleChange});
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _heightCtrl = TextEditingController();
  final _weightCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  String _gender = 'male';

  void _next() {
    final h = double.tryParse(_heightCtrl.text) ?? 170;
    final w = double.tryParse(_weightCtrl.text) ?? 70;
    final a = int.tryParse(_ageCtrl.text) ?? 30;
    double bmr;
    if (_gender == 'male') {
      bmr = 10 * w + 6.25 * h - 5 * a + 5;
    } else {
      bmr = 10 * w + 6.25 * h - 5 * a - 161;
    }
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('السعرات الأساسية'),
      content: Text('BMR ≈ ${bmr.toStringAsFixed(0)} kcal/day'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('أول حاجة نعرفها عنك')),
      body: Padding(
        padding: EdgeInsets.all(ZF.spacingM),
        child: Column(
          children: [
            TextField(controller: _heightCtrl, decoration: InputDecoration(labelText: 'الطول (سم)')),
            TextField(controller: _weightCtrl, decoration: InputDecoration(labelText: 'الوزن (كجم)')),
            TextField(controller: _ageCtrl, decoration: InputDecoration(labelText: 'السن')),
            SizedBox(height: ZF.spacingM),
            ElevatedButton(onPressed: _next, child: Text('حساب وإظهار الخطة الأساسية')),
            SizedBox(height: ZF.spacingS),
            TextButton(onPressed: () => widget.onLocaleChange(Locale('en')), child: Text('English')),
          ],
        ),
      ),
    );
  }
}
