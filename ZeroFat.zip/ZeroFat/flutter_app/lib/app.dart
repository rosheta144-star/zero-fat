import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme/design_tokens.dart';
import 'screens/onboarding_screen.dart';

class ZeroFatApp extends StatefulWidget {
  @override
  _ZeroFatAppState createState() => _ZeroFatAppState();
}

class _ZeroFatAppState extends State<ZeroFatApp> {
  Locale _locale = Locale('ar');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ZeroFat',
      locale: _locale,
      supportedLocales: [Locale('ar'), Locale('en')],
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      theme: appTheme(_locale),
      home: OnboardingScreen(onLocaleChange: (l) => setState(() => _locale = l)),
    );
  }
}
