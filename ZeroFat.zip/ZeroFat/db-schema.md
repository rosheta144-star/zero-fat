# MongoDB Schema - ZeroFat (Mongoose models)

Collections:

1. users
 - _id: ObjectId
 - name: string
 - email: string (unique, sparse)
 - phone: string (unique, sparse)
 - passwordHash: string
 - role: enum ['owner','admin','nutritionist','client']
 - avatarUrl: string
 - meta: object
 - createdAt: Date

2. clients
 - _id
 - user: ObjectId -> users
 - personal: { dob, gender, heightCm, weightKg, goal }
 - medicalHistory: string
 - allergies: [string]
 - medications: [string]
 - assignedNutritionists: [ObjectId -> users]
 - files: [ObjectId -> media]
 - measurements: [ObjectId -> measurements]
 - createdAt: Date
