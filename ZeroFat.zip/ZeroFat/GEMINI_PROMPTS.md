### InBody analysis
سياق: المريض: {client.name}، عمره {age} سنة، جنس: {gender}. بيانات InBody بتاريخ {date}:
- الوزن: {weight} كجم
- نسبة الدهون: {fatPercent} %
- العضلات: {muscleKg} كجم
- مؤشر كتلة الجسم BMI: {bmi}

مطلوب: اكتب تقرير طبي قصير...
